<!DOCTYPE html>
<html lang="en">

    <head>
        
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
        
        <title>Recipedia</title>
        
    </head>
    
    <body>
        
        <header class="bgimage">
            
            <div class="container-fluid">
                <div class="row">
                    <h1>Create Account</h1>
                </div>
            </div>    
            
            <div class="container-fluid navigation">
                <div class="row">
                    <div class="col-sm-3 tabs"> <a href="index.php">Search</a> </div>
                    <div class="col-sm-3 tabs"> <a href="create_recipe.php">Create</a> </div>
                    <div class="col-sm-3 tabs"> <a href="saved_recipes.php">Saved Recipes</a> </div>
                    <div class="col-sm-3 tabs"> <a href="my_account.php">My Account</a> </div>
					  <div class="col-sm-3 tabs"> <a href="admin_functions.php">Admin Functions</a> </div>
					  <div class="col-sm-3 tabs"> <a href="admin_functions.php">Create Account</a> </div>
                </div>
            </div>
            
        </header> 

			 <div class="container-fluid">
                <div class="row">
                    <h2>Enter New Account Info</h2>
                </div>
            </div> 		
            
            <div class="container-fluid">
            <div class="row">
                <div class="col-sm-2 refine">
					<form action="create_account.php" method="POST" enctype="multipart/form-data">
						<div class="textField">
							<label for="username">Username:</label>
							<input type="text" name="user_name" id="username">
						</div>
						
						<div class="textField">
							<label for="password">Password:</label>
							<input type="password" name="password" id="password">
						</div>
						
						<br />
				
						<div id="button">
							<input type = "submit" name="create_account" value ="Create Account"/>
						</div>						
					</form>
                </div>

                <?php 
					if (isset($_POST['create_account'])){
						//connect to the database
						$db = new PDO('mysql:dbname=recipes_app','root');
						
						// Check for posted username
						if (isset ($_POST['user_name'])) {
							$username = $_POST['user_name'];
							
							// Prepare and execute sanitized statement to avoid SQL injection in the username field
							$user_check = 'SELECT user_name FROM users WHERE user_name = :user_name';
							$user_statement = $db->prepare($user_check);
							$parameters = array(':user_name' => $username);
							$user_statement->execute($parameters);
							
							// Fetch results, if any
							$user_result = $user_statement->fetch();
							$user_fetch = $user_result['user_name'];
							
							// If username is not already found is database...
							if (strtoupper($user_fetch) != strtoupper($username)) {
								// Check for posted password
								if (isset ($_POST['password'])) {
									$password = $_POST['password'];
									
									// hash the password
									$hash = password_hash($password, PASSWORD_DEFAULT);
									
									
									// Prepare and execute sanitized statement to avoid SQL injection in either form field
									$sql = 'INSERT INTO users (user_name, user_password) VALUES (:user_name, :user_password)';
									$statement = $db->prepare($sql);
									$parameters = array(':user_name' => $username, ':user_password' => $hash);
									$statement->execute($parameters);
									
									echo "<p>Account successfully created. You are now logged in.</p>";
									
									// End previous session (if any), and start a new one
									if (isset($_SESSION))           
									{
										session_destroy();              
										session_start();              
										session_regenerate_id(TRUE);
									}
									// Set session variable for tracking logged in user across multiple pages
									$_SESSION["name"] = $username;
								}
								else {
									echo "<p>Please enter a password.</p>";
								}
							}
							else {
								echo "<p>The username has already been taken, please select a different username.</p>";
							}
						}
						else {
							echo "<p>Please enter a username.</p>";
						}
					}
                ?>
            </div>          
        </div>
	
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="script.js"></script>
	</body>

</html>