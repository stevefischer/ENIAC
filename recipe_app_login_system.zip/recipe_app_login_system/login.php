<!DOCTYPE html>
<html lang="en">

    <head>
        
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
        
        <title>Recipedia</title>
        
    </head>
    
    <body>
        
        <header class="bgimage">
            
            <div class="container-fluid">
                <div class="row">
                    <h1>Login</h1>
                </div>
            </div>    
            
            <div class="container-fluid navigation">
                <div class="row">
                    <div class="col-sm-3 tabs"> <a href="index.php">Search</a> </div>
                    <div class="col-sm-3 tabs"> <a href="create_recipe.php">Create</a> </div>
                    <div class="col-sm-3 tabs"> <a href="saved_recipes.php">Saved Recipes</a> </div>
                    <div class="col-sm-3 tabs"> <a href="my_account.php">My Account</a> </div>
					  <div class="col-sm-3 tabs"> <a href="admin_functions.php">Admin Functions</a> </div>
					  <div class="col-sm-3 tabs"> <a href="create_account.php">Create Account</a> </div>
					  <div class="col-sm-3 tabs"> <a href="login.php">Login</a> </div>
                </div>
            </div>
            
        </header> 

			 <div class="container-fluid">
                <div class="row">
                    <h2>Login</h2>
                </div>
            </div> 		
            
            <div class="container-fluid">
            <div class="row">
                <div class="col-sm-2 refine">
					<form action="login.php" method="POST" enctype="multipart/form-data">
						<div class="textField">
							<label for="username">Username:</label>
							<input type="text" name="user_name" id="username">
						</div>
						
						<div class="textField">
							<label for="password">Password:</label>
							<input type="password" name="password" id="password">
						</div>
						
						<br />
				
						<div id="button">
							<input type = "submit" name="login" value ="Login"/>
						</div>						
					</form>
                </div>

                <?php 
					if (isset($_POST['login'])){
						//connect to the database
						$db = new PDO('mysql:dbname=recipes_app','root');
						
						// Check for posted username
						if (isset ($_POST['user_name'])) {
							$username = $_POST['user_name'];
							
							// Prepare and execute sanitized statement to avoid SQL injection in the username field
							$user_check = 'SELECT user_name FROM users WHERE user_name = :user_name';
							$user_statement = $db->prepare($user_check);
							$parameters = array(':user_name' => $username);
							$user_statement->execute($parameters);
							
							// Fetch results, if any
							$user_result = $user_statement->fetch();
							$user_fetch = $user_result['user_name'];
							
							// If username is found is database...
							if ($user_fetch == $username) {
								
								// ...start checking the password
								if (isset ($_POST['password'])) {
									
									// Check to see if password matches in database
									$password = $_POST['password'];
									$pass_check = 'SELECT user_password FROM users WHERE user_name = :user_name';
									$pass_statement = $db->prepare($pass_check);
									// Parameters should be identical, comparing submitted login credentials against the username
									$pass_statement->execute($parameters);
									
									// Fetch results, if any
									$pass_result = $pass_statement->fetch();	
									$pass_hash = $pass_result['user_password'];
									
									// If password is verified
									if (password_verify($password, $pass_hash)) {
										
										// End previous session (if any), and start a new one
										if (isset($_SESSION))           
										{
											
											session_destroy();              
											session_start();
											session_regenerate_id(TRUE);
										}
										// Set session variable for tracking logged in user across multiple pages
										$_SESSION["name"] = $username;
										echo "<p>You are successfully logged in.</p>";
									}
									// If username and password are entered, but do not match a row in the database
									else {
										
										// Output holding variable - login credentials do not match any existing account
										echo "<p>Login credentials do not match, please input a correct username and password.</p>";
									}
								}
								// If password field is not filled out, will require additional scripting to check for an empty string in the password field
								else {
									
									// Output holding variable - password not entered
									echo "<p>Please enter a password.</p>";
								}
							}
							//  If username is not found in database
							else {
								
								// Output holding variable - login credentials do not match any existing account
								echo "<p>Login credentials do not match, please input a correct username and password.</p>";
							}
						}
						else {
							echo "<p>Please enter a username.</p>";
						}
					}
                ?>
            </div>          
        </div>
	
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="script.js"></script>
	</body>

</html>